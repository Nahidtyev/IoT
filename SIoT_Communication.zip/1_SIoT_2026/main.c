#include <msp430.h>
#include <intrinsics.h>
#include <main.h>

char *regnames[62] = {"IOCFG2:\t\t",
                            "I0CFG1:\t\t",
                            "I0CFG0:\t\t",
                            "FIFOTHR:\t",
                            "SYNC1:\t\t",
                            "SYNC0:\t\t",
                            "PKTLEN:\t\t",
                            "PKTCTRL1:\t",
                            "PKTCTRL0:\t",
                            "ADDR:\t\t",
                            "CHANNR:\t\t",
                            "FSCTRL1:\t",
                            "FSCTRL0:\t",
                            "FREQ2:\t\t",
                            "FREQ1:\t\t",
                            "FREQ0:\t\t",
                            "MDMCFG4:\t",
                            "MDMCFG3:\t",
                            "MDMCFG2:\t",
                            "MDMCFG1:\t",
                            "MDMCFG0:\t",
                            "DEVIATN:\t",
                            "MCSM2:\t\t",
                            "MCSM1:\t\t",
                            "MCSM0:\t\t",
                            "FOCCFG:\t\t",
                            "BSCFG:\t\t",
                            "AGCCTRL2:\t",
                            "AGCCTRL1:\t",
                            "AGCCTRL0:\t",
                            "WOREVT1:\t",
                            "WOREVT0:\t",
                            "WORCTRL:\t",
                            "FREND1:\t\t",
                            "FREND0:\t\t",
                            "FSCAL3:\t\t",
                            "FSCAL2:\t\t",
                            "FSCAL1:\t\t",
                            "FSCAL0:\t\t",
                            "RCCTRL1:\t",
                            "RCCTRL0:\t",
                            "FSTEST:\t\t",
                            "PTEST:\t\t",
                            "AGCTEST:\t",
                            "TEST2:\t\t",
                            "TEST1:\t\t",
                            "TEST0:\t\t",
                            " 0x2F :\t\t",
                            "PARTNUM:\t",
                            "VERSION:\t",
                            "FREQEST:\t",
                            "LQI:\t\t",
                            "RSSI:\t\t",
                            "MARCSTATE:\t",
                            "WORTIME1:\t",
                            "WORTIME0:\t",
                            "PKTSTATUS:\t",
                            "VCO_VC_DAC:\t",
                            "TXBYTES:\t",
                            "RXBYTES:\t",
                            "RCCTRL1_STATUS:\t",
                            "RCCTRL0_STATUS:\t"
};

void main()
{
    char sR, data;

    board_init();

    UART_Init();
    SPI_Init();


    {
        unsigned char RRegVal[2][62];
        for(unsigned char s=0; s<2; s++)
        {
            P3OUT &= 0xFE; // CSn = LOW
            delay_us(150);

            SPI_Send(0xC0); // burst read starting from register address=0x00
            SPI_Read(&sR); // save CC2500 status byte


            for(unsigned char i=0; i<47; i++)
            {
                SPI_Send(0xFF); // dummy byte
                RRegVal[s][i] = UCB0RXBUF;// save received Register value    //SPI_Read(&data); //
            }
            P3OUT |= 0x01; // CSn = HIGH

            for(unsigned char i=0x30; i<0x3D; i++)
            {
                P3OUT &= 0xFE; // CSn = LOW
                delay_us(150);

                SPI_Send(0xC0 + i);
                SPI_Send(0x00);
                RRegVal[s][i] = UCB0RXBUF;

                P3OUT |= 0x01; // CSn = HIGH
            }

            if(s==0)
                CC_Init();
        }


        for(unsigned char i=0; i<62; i++)
        {
            SerialWrite(regnames[i]);
            SerialWrite(IToA(RRegVal[0][i], 16));
            SerialWrite("\t");
            SerialWriteln(IToA(RRegVal[1][i], 16));
        }
        sR=0;
    }

    while(1)
    {

    }
}

/*
    UART_Init();
    SPI_Init();

    CC_Protocol_t CC_TX, CC_RX;
    CC_TX.LEN = 0;
    CC_RX.LEN = 0;
    CC_TX.ADDRESS = 0;
    CC_RX.ADDRESS = 0;
    for(unsigned char i=0; i<62; i++)
    {
        CC_TX.DATA[i] = 0;
        CC_RX.DATA[i] = 0;
    }

    // networking
    CC_SetChannel( 0xE7 );  // all devices in this network must use the same channel
    CC_SetAddress( 0xC3 );    // the device address must be unique inside the network

    // send "hello world"
    CC_AddData(&CC_TX, "Hello World ");
    CC_AddData(&CC_TX, IToA(52, 10));
    CC_TX.ADDRESS = 0xC4; // the address of destination node
    CC_SendMessage(CC_TX); // send message

    Status.GDO_0_Set = 0;
    CC_Strobe(CC2500_SRX); // Go to RX state

    {
        char bytes=0;
        int cnt = 0;
        while(!Status.GDO_0_Set)
        {
            CC_ReadReg(CC2500_RXBYTES | 0xC0, &bytes); // read RXBYTES register value
            if(bytes == 0)
                cnt++;
            else
                break; // go out of this loop

            if(cnt==10)
            {
                cnt=0;
                delay_ms(1000);
            }
            else
                delay_us(100);
        }
        CC_ReadMessage(&CC_RX);
    }




    while(1)
    {
        SerialWrite("Hello");
        SerialWriteln(" World!");
    }
}*/
