# FIXED

main.obj: ../main.c
main.obj: C:/ti/ccs1200/ccs/ccs_base/msp430/include/msp430.h
main.obj: C:/ti/ccs1200/ccs/ccs_base/msp430/include/msp430f2274.h
main.obj: C:/ti/ccs1200/ccs/ccs_base/msp430/include/in430.h
main.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
main.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
main.obj: C:/Users/Admin/workspace_v12/1_SIoT_2026/main.h
main.obj: C:/Users/Admin/workspace_v12/1_SIoT_2026/Communication/uart.h
main.obj: C:/Users/Admin/workspace_v12/1_SIoT_2026/utils/Typedefs.h
main.obj: C:/Users/Admin/workspace_v12/1_SIoT_2026/Communication/cc2500.h
main.obj: C:/Users/Admin/workspace_v12/1_SIoT_2026/utils/board.h
main.obj: C:/Users/Admin/workspace_v12/1_SIoT_2026/utils/adc.h
main.obj: C:/Users/Admin/workspace_v12/1_SIoT_2026/utils/board.h

../main.c:

C:/ti/ccs1200/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs1200/ccs/ccs_base/msp430/include/msp430f2274.h:

C:/ti/ccs1200/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

C:/Users/Admin/workspace_v12/1_SIoT_2026/main.h:

C:/Users/Admin/workspace_v12/1_SIoT_2026/Communication/uart.h:

C:/Users/Admin/workspace_v12/1_SIoT_2026/utils/Typedefs.h:

C:/Users/Admin/workspace_v12/1_SIoT_2026/Communication/cc2500.h:

C:/Users/Admin/workspace_v12/1_SIoT_2026/utils/board.h:

C:/Users/Admin/workspace_v12/1_SIoT_2026/utils/adc.h:

C:/Users/Admin/workspace_v12/1_SIoT_2026/utils/board.h:

