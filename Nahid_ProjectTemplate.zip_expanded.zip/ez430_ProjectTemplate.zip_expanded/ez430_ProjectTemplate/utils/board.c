#include "board.h"
#include "Typedefs.h"

extern __Status_t Status;
extern char UART_RxBuf[8];

void board_init()
{
    WDTCTL = WDTPW | WDTHOLD;

    BCSCTL1 = CALBC1_8MHZ;
    DCOCTL = CALDCO_8MHZ;
    BCSCTL3 &= 0xCF;
    BCSCTL3 |= LFXT1S_2;

    P1DIR = 0x03;
    P1REN = BIT2;
    P1OUT = BIT2;
    P1IFG = 0;
    P1IE  = BIT2;
    P1IES |= BIT2;
    __asm(" EINT");
}

void delay_ms(unsigned int ms)
{
    if(ms < 5461)
    {
        TAR = 0;
        TACCR0 = 12 * ms;
        TACCTL0 = 0x0010;
        TACTL = 0x0110;
        __low_power_mode_3();
    }
}

void delay_us(unsigned int us)
{
    if(us < 16383)
    {
        TAR = 0;
        TACCR0 = 4 * us;
        TACCTL0 = 0x0010;
        TACTL = 0x0210;
        __low_power_mode_0();
    }
}

void wait()
{
    __low_power_mode_0();
}

void SPI_Init()
{
    UCB0CTL0 = 0xA9;
    UCB0CTL1 = 0xC1;
    UCB0BR0 = 4;

    P3SEL &= 0xF0;
    P3SEL |= 0x0E;

    P3DIR = 0x01;
    P3OUT = 0x01;

    UCB0CTL1 &= 0xFE;
}

void SPI_Send(char B)
{
    IFG2 &= ~UCB0RXIFG;
    UCB0TXBUF = B;
    while(!(IFG2 & UCB0RXIFG));
}

void SPI_Read(char* ptr)
{
    *ptr = UCB0RXBUF;
}


#pragma vector=PORT1_VECTOR
__interrupt void Port1_ISR()
{
    if(P1IFG & BIT2)
    {
        P1IFG &= ~BIT2;

        if(!(P1IN & BIT2))
        {
            P1OUT |= BIT0;
            P1IES &= ~BIT2;
        }
        else
        {
            P1OUT &= ~BIT0;
            P1IES |= BIT2;
        }

        Status.Button = 1;
    }
    __low_power_mode_off_on_exit();
}

#pragma vector=PORT2_VECTOR
__interrupt void Port_2_ISR(void)
{
    if(P2IFG & 0b10000000)
    {
        P2IFG &= 0b01111111;
        Status.GDO_2_Set = 1;
    }
    if(P2IFG & 0b01000000)
    {
        P2IFG &= 0b10111111;
        Status.GDO_0_Set = 1;
    }
    __low_power_mode_off_on_exit();
}

#pragma vector=TIMERA0_VECTOR
__interrupt void TIMERA0()
{
    TACTL &= 0xFFCF;
    __low_power_mode_off_on_exit();
}

#pragma vector=USCIAB0RX_VECTOR
__interrupt void UART_Rx()
{
    if(IFG2 & 0x01)
    {
        if(UCA0RXBUF != 13)
        {
            UART_RxBuf[Status.UART_RX_cnt] = UCA0RXBUF;
            UCA0TXBUF = UART_RxBuf[Status.UART_RX_cnt++];
            while(UCA0STAT & 0x01);
        }
        else
            Status.UART_RX = 1;
    }
    __low_power_mode_off_on_exit();
}

#pragma vector=ADC10_VECTOR
__interrupt void ADC_Done(void)
{
    adcStatus.DataReady = 1;
    adcStatus.ADC_Val = ADC10MEM;
    __low_power_mode_off_on_exit();
}
