# FIXED

main.obj: ../main.c
main.obj: C:/ti/ccs1210/ccs/ccs_base/msp430/include/msp430.h
main.obj: C:/ti/ccs1210/ccs/ccs_base/msp430/include/msp430f2274.h
main.obj: C:/ti/ccs1210/ccs/ccs_base/msp430/include/in430.h
main.obj: C:/ti/ccs1210/ccs/tools/compiler/ti-cgt-msp430_21.6.0.LTS/include/intrinsics.h
main.obj: C:/ti/ccs1210/ccs/tools/compiler/ti-cgt-msp430_21.6.0.LTS/include/intrinsics_legacy_undefs.h
main.obj: C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/main.h
main.obj: C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/Communication/uart.h
main.obj: C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/utils/Typedefs.h
main.obj: C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/Communication/cc2500.h
main.obj: C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/utils/board.h
main.obj: C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/utils/adc.h
main.obj: C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/utils/board.h

../main.c:

C:/ti/ccs1210/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs1210/ccs/ccs_base/msp430/include/msp430f2274.h:

C:/ti/ccs1210/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs1210/ccs/tools/compiler/ti-cgt-msp430_21.6.0.LTS/include/intrinsics.h:

C:/ti/ccs1210/ccs/tools/compiler/ti-cgt-msp430_21.6.0.LTS/include/intrinsics_legacy_undefs.h:

C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/main.h:

C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/Communication/uart.h:

C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/utils/Typedefs.h:

C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/Communication/cc2500.h:

C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/utils/board.h:

C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/utils/adc.h:

C:/Users/User/workspace_v12/ez430_ProjectTemplate.zip_expanded/ez430_ProjectTemplate/utils/board.h:

